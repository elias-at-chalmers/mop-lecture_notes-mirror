#include <stdint.h>
#include <stdio.h>

// Detta är filen där eleverna skall implementera sina funktioner. 
// Uppgiften kan till exempel vara: "Implementera delay(ns)" nedan. 



// WCH CH32V SysTick register definitions
#define STK_BASE     0xE000F000UL
#define STK_CTLR     ((volatile uint32_t *)(STK_BASE + 0x00))
#define STK_SR       ((volatile uint32_t *)(STK_BASE + 0x04))
#define STK_CNT      ((volatile uint64_t *)(STK_BASE + 0x08))
#define STK_CMP      ((volatile uint64_t *)(STK_BASE + 0x10))

// STK_CTLR bits
#define STK_CTLR_STE     (1 << 0) // Counter enable
#define STK_CTLR_STIE    (1 << 1) // Interrupt enable (not used here)
#define STK_CTLR_STCLK   (1 << 2) // Clock source: 1 = HCLK, 0 = HCLK/8
#define STK_CTLR_STRE    (1 << 3) // Auto-reload enable (not used here)
#define STK_CTLR_MODE    (1 << 4) // Mode (not used here)
#define STK_CTLR_INIT    (1 << 5) // Mode (not used here)
#define STK_CTLR_SWIE    (1 << 31) // Software interrupt (not used here)

#define SYSCLK_HZ 144000000UL

void delay(uint64_t ns)
{
	// Convert ns to ticks (144MHz = 144 ticks per microsecond = 0.144 ticks per ns)
	uint64_t ticks = ns / 6.9444444; // approximately ns * (144 / 1000)
	*STK_CTLR = 0; // Disable SysTick
	*STK_CMP = ticks; // Set compare value
	*STK_CNT = 0; // Reset counter
	*STK_SR = 0; // Clear status register
	*STK_CTLR = STK_CTLR_STE | STK_CTLR_STCLK; // Enable, use HCLK
	// Wait for count flag (bit 0 in STK_SR)
	while ((*STK_SR & 1) == 0) {
		// busy wait
	}
	*STK_CTLR = 0; // Disable SysTick
}