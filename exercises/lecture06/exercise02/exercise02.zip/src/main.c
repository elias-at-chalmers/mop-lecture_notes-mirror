#include <stdio.h>
#include <stdint.h>

extern void delay(uint64_t ns);


///////////////////////////////////////////////////////////////////////////////
// Basic Timers
//
#define TIMER6_IRQ_NUM    70
#define TIMER7_IRQ_NUM    71

typedef struct {
    union {
        uint32_t CTRL1;            // 0x00
        struct {
            uint32_t enable : 1;
            uint32_t udis   : 1;
            uint32_t urs    : 1;
            uint32_t opm    : 1;
            uint32_t        : 3;
            uint32_t arpe   : 1;
            uint32_t        : 24;
        } ctrl1;
    };
    uint32_t CTRL2;                // 0x04
    uint32_t RESERVED0;            // 0x08
    uint32_t DMAINTENR;             // 0x0C
    uint32_t INTFR;                 // 0x10
    uint32_t SWEVGR;                // 0x14
    uint32_t RESERVED1[3];          // 0x18, 0x1C, 0x20
    uint32_t CNT;                   // 0x24 (lower 16 bits valid)
    uint32_t PSC;                   // 0x28 (lower 16 bits valid)
    uint32_t ATRLR;                 // 0x2C (lower 16 bits valid)
} TIMER_t; 

volatile TIMER_t* timer6 = (TIMER_t*)0x40001000;
volatile TIMER_t* timer7 = (TIMER_t*)0x40001400;
///////////////////////////////////////////////////////////////////////////////

int main(void)
{
    // Koden nedan fungerar på hårdvaran, förutom första iterationen. 
    // (det verkar som PSC inte blir aktiv förrän den nått ATRLR en gång)
    //
    // Delayen är på 10us, och TIMER6 räknar till 14us ungefär varje gång.
    // 
    // På simulatorn rapporterar den istället: 
    // Your delay took 5070us

    while(1) {
        // Set up timer 6 
        *timer6 = (TIMER_t){0}; // Clear everything to 0
        timer6->ctrl1.enable = 0;
        timer6->CNT = 0;   // Reset counter
        timer6->PSC = 143;  // Tick every 1us (144MHz / (143 + 1) = 1MHz)
        timer6->ATRLR = 0xFFFF; 
        timer6->ctrl1.enable = 1; // Enable timer    

        delay(10000);

        uint32_t us = timer6->CNT;
        printf("Your delay took: %uus\n", (unsigned int) us);
    }
}

